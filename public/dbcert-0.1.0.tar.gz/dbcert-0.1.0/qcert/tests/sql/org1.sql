select *
from employees
;
