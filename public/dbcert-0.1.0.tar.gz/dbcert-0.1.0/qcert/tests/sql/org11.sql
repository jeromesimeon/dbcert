select age, name
from students, employees
where eid = 1
  and sid = 1
;
