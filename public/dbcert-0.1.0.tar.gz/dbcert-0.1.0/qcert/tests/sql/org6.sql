select *
from employees
where age = 32
;
