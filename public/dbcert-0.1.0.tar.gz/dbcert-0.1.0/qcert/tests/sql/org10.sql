select *
from employees
where age = 32
except
select *
from employees
;
