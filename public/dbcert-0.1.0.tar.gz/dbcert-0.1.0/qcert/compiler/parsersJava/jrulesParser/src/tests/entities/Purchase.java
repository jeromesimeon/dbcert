package tests.entities;

import tests.Entity;

public class Purchase extends Entity {
	public int pid;
	public int cid;
	public String name;
	public int quantity;
}
