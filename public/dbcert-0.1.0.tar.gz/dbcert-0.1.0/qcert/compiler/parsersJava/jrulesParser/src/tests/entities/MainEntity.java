package tests.entities;

import tests.Entity;

public class MainEntity extends Entity {
	public int id;
	public int doubleAttribute;
	public String stringId;
}
