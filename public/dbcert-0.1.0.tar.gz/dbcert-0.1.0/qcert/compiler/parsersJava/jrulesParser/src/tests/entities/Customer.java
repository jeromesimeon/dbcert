package tests.entities;

import tests.Entity;

public class Customer extends Entity {
	public int cid;
	public String name;
	public int age;
}
