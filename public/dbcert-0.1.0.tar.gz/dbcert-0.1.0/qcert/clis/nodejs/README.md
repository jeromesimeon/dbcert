# Q*cert for Node.js

This is a Node.js package to call the Q*cert compiler, and execute on the JavaScript backend.

