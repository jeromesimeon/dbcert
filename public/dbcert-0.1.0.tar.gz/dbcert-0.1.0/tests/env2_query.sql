create table t1 (a1 integer, b1 integer);
create table t2 (a2 integer, b2 integer);

select a1 from t1 group by a1 having exists (select a2 from t2 group by a2);
-- Result: [{"a1":1},{"a1":2},{"a1":3},{"a1":4}]

select sum(1+a1*0+b1*0) from t1;
-- Result: [{"c1":30}]

select a1, sum(b1+1) from t1 group by a1;
-- Result: [{"c1":65,"a1":1},{"c1":65,"a1":2},{"c1":20,"a1":3},{"c1":45,"a1":4}]
