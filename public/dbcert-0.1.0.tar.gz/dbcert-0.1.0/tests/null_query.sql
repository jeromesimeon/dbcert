create table R (A integer);
create table S (A integer);

select R.A from R where R.A not in (select S.A from S);
-- Result: []

select R.A from R where not exists (select * from S where S.A = R.A);
-- Result: [{"A":1},{"A":null}]

select R.A from R except select S.A from S;
-- Result: [{"A":1}]
