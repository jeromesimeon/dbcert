create table t1 (a1 integer, b1 integer);
create table t2 (a2 integer, b2 integer);

select a1 from t1 group by a1 having exists (select a2 from t2 group by a2 having sum(1+0*a1+0*b2) = 2);
-- Should be [{"a1":1},{"a1":2},{"a1":3},{"a1":4}]

select a1 from t1 group by a1 having exists (select a2 from t2 group by a2 having sum(1+0*a1+0*b2) = 8);
-- Should be []
