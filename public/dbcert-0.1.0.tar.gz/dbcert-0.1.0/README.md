# DBCert

A Coq specification and formalization of a compiler from SQL to ECMA 6.

## Requirements

This work is known to compile with Node.js 10, OCaml-4.07.1 and Coq-8.8.*. Se below for installation instruction.

### Install Node.js

We recommend Node.js version 10, which can be downloaded and installed from [https://nodejs.org/en/download/releases/](https://nodejs.org/en/download/releases/).

If you already have Node.js and `nvm` installed, you can switch to Node 10 with:
```
nvm use 10
```

### Install OCaml

We recommend installing OCaml through opam.

```
sudo curl -sL https://raw.githubusercontent.com/ocaml/opam/master/shell/install.sh > install.sh
echo | sudo sh install.sh
eval $(opam env)
```

If you have Opam already installed, you can switch to OCaml 4.07.1 with:

```
opam switch create 4.07.1 || true
opam switch set 4.07.1
opam update || true
opam upgrade || true
```

### Install OCaml dependencies

```
opam install -y --jobs=2 dune menhir camlp5 base64 js_of_ocaml js_of_ocaml-ppx re
```

### Install Coq dependencies

```
opam repo add coq-released https://coq.inria.fr/opam/released
opam install -y -v coq.8.8.2 coq-flocq coq-jsast.1.0.9
```

## Compile DBCert

If not done yet, ungzip and untar the DBCert package:
```
cat dbcert-0.1.0.tar.gz | gunzip | tar xvf -
```

This should create a new `dbcert-0.1.0` directory.

Then compile DBCert with:

```
cd dbcert-0.1.0
make
```

This will compile the full mechanization, extract it to OCaml, and produce an executable `./extraction/dbcert`. Note that compilation can take quite a while.

## Try DBCert

To compile SQL to JavaScript and link the runtime:
```
./dbcert -link tests/org1.sql
```
To run the compiled JavaScript:
```
node ./dbcertRun.js tests/org1.js tests/db1.json
```

## Examples

We provide a bunch of examples in the `extraction/tests` directory. They can be run as presented in the previous section.
- `orgX.sql` are simple queries to get started. They should be run in the `db1.json` database.
- `null_query.sql` are non-trivial queries involving the SQL `null` value, taken from [11]. They should be run in the `null_db.json` database.
- `env_query.sql` and `env2_query.sql` are non-trivial queries involving the SQL environment handling, taken from [4]. They should be run in the `env_db.json` database.
