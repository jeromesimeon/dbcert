create table employees (name text, age int);
select avg(age)
from employees
where age > 32;
