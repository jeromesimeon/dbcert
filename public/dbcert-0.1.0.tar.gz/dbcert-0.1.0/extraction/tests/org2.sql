create table employees (name text, age int);
select name
from employees
where age > 32;
