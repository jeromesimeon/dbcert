(************************************************************************************)
(**                                                                                 *)
(**                             The DBCert Library                                  *)
(**                                                                                 *)
(**            LRI, CNRS & Université Paris-Sud, Université Paris-Saclay            *)
(**                                                                                 *)
(**                        Copyright 2016-2019 : FormalData                         *)
(**                                                                                 *)
(**         Authors: Véronique Benzaken                                             *)
(**                  Évelyne Contejean                                              *)
(**                  Mohammed Hachmaoui                                             *)
(**                  Chantal Keller                                                 *)
(**                                                                                 *)
(************************************************************************************)


(*** Glue around the extracted compiler ***)
open QcertUtils

(** Glue for SELECT queries **)

let relname_to_extracted : Basics.relname -> Sql_query_to_js.relname
  = Util.char_list_of_string

let set_op_to_extracted : Basics.set_op -> Sql_query_to_js.set_op = function
  | Basics.Union -> Sql_query_to_js.Union
  | Basics.Intersect -> Sql_query_to_js.Inter
  | Basics.Except -> Sql_query_to_js.Diff

let and_or_to_extracted : Basics.and_or -> Sql_query_to_js.and_or = function
  | Basics.And_F -> Sql_query_to_js.And_F
  | Basics.Or_F -> Sql_query_to_js.Or_F

let quantifier_to_extracted : Basics.quantifier -> Sql_query_to_js.quantifier = function
  | Basics.Forall_F -> Sql_query_to_js.Forall_F
  | Basics.Exists_F -> Sql_query_to_js.Exists_F

let typed_aname_to_extracted : Basics.typed_aname -> Sql_query_to_js.Tuple.attribute = function
  | (n, Basics.TInt) -> Obj.magic (Sql_query_to_js.Attr_Z (Util.char_list_of_string n))
  | (n, Basics.TString) -> Obj.magic (Sql_query_to_js.Attr_string (Util.char_list_of_string n))
  | (n, Basics.TBool) -> Obj.magic (Sql_query_to_js.Attr_bool (Util.char_list_of_string n))

let typed_attribute_name_to_extracted : Basics.typed_attribute_name -> Sql_query_to_js.Tuple.attribute =
  fun ((r, n), ty) ->
  let n = match r with Some r -> r^"."^n | None -> n in
  typed_aname_to_extracted (n, ty)

let symb_to_extracted : Basics.symb -> int -> Sql_query_to_js.Tuple.symbol =
  fun s a -> Obj.magic (Sql_query_to_js.Symbol (Util.char_list_of_string (Basics.string_of_symb s a)))

let predicate_to_extracted : Basics.predicate -> Sql_query_to_js.aggterm list -> Sql_query_to_js.Tuple.predicate * Sql_query_to_js.aggterm list =
  fun p l ->
  let (p, l) =
    (* TODO: remove when predicates are not exported to binops but to
       any NRAEnv expression *)
    match Basics.string_of_predicate p with
      | "<" -> ("<", l)
      | "<=" -> ("<=", l)
      | ">" -> ("<", List.rev l)
      | ">=" -> ("<=", List.rev l)
      | "=" -> ("=", l)
      | p -> (p, l)
  in
  (Obj.magic (Util.char_list_of_string p), l)

let aggregate_to_extracted : Basics.aggregate -> Sql_query_to_js.Tuple.aggregate =
  fun a -> Obj.magic (Util.char_list_of_string (Basics.string_of_aggregate a))

let value_to_extracted : Basics.value -> Sql_query_to_js.Tuple.value =
  fun v -> Obj.magic (
               match v with
                 (* We consider NULL values as untyped, and put them into bool values *)
                 | Basics.VNull -> Sql_query_to_js.NullValues.Value_bool None
                 | Basics.VString s -> Sql_query_to_js.NullValues.Value_string (Some (Util.char_list_of_string s))
                 | Basics.VInt i -> Sql_query_to_js.NullValues.Value_Z (Some i)
                 | Basics.VBool b -> Sql_query_to_js.NullValues.Value_bool (Some b)
             )

let rec funterm_to_extracted : Coq_sql_algebra.funterm -> Sql_query_to_js.funterm = function
  | Coq_sql_algebra.F_Constant v -> Sql_query_to_js.F_Constant (value_to_extracted v)
  | Coq_sql_algebra.F_Dot tan -> Sql_query_to_js.F_Dot (typed_attribute_name_to_extracted tan)
  | Coq_sql_algebra.F_Expr (s, l) -> Sql_query_to_js.F_Expr (symb_to_extracted s (List.length l), List.map funterm_to_extracted l)

let rec aggterm_to_extracted : Coq_sql_algebra.aggterm -> Sql_query_to_js.aggterm = function
  | Coq_sql_algebra.A_Expr f -> Sql_query_to_js.A_Expr (funterm_to_extracted f)
  | Coq_sql_algebra.A_agg (a, f) -> Sql_query_to_js.A_agg (aggregate_to_extracted a, funterm_to_extracted f)
  | Coq_sql_algebra.A_fun (s, l) -> Sql_query_to_js.A_fun (symb_to_extracted s (List.length l), List.map aggterm_to_extracted l)

let select_to_extracted : Coq_sql_algebra.select -> Sql_query_to_js.select = function
  | Coq_sql_algebra.Select_As (a, n) -> Sql_query_to_js.Select_As (aggterm_to_extracted a, typed_aname_to_extracted n)

let select_item_to_extracted : Coq_sql_algebra.select_item -> Sql_query_to_js.select_item = function
  | Coq_sql_algebra.Select_Star -> Sql_query_to_js.Select_Star
  | Coq_sql_algebra.Select_List l -> Sql_query_to_js.Select_List (List.map select_to_extracted l)

let groub_by_to_extracted : ToCoq.group_by -> Sql_query_to_js.group_by = function
  | ToCoq.Group_By l -> Sql_query_to_js.Group_By (List.map (fun f -> Sql_query_to_js.A_Expr (funterm_to_extracted f)) l)
  | ToCoq.Group_Fine -> Sql_query_to_js.Group_Fine

let att_renaming_to_extracted : ToCoq.att_renaming -> Sql_query_to_js.att_renaming = function
  | ToCoq.Att_As (tan1, tan2) -> Sql_query_to_js.Att_As (typed_attribute_name_to_extracted tan1, typed_attribute_name_to_extracted tan2)

let att_renaming_item_to_extracted : ToCoq.att_renaming_item -> Sql_query_to_js.att_renaming_item = function
  | ToCoq.Att_Ren_Star -> Sql_query_to_js.Att_Ren_Star
  | ToCoq.Att_Ren_List l -> Sql_query_to_js.Att_Ren_List (List.map att_renaming_to_extracted l)

let rec sql_query_to_extracted
    : ToCoq.sql_query -> Sql_query_to_js.relname Sql_query_to_js.sql_query0
  = function
  | ToCoq.Sql_Table r -> Sql_query_to_js.Sql_Table (relname_to_extracted r)
  | ToCoq.Sql_Set (op, q1, q2) -> Sql_query_to_js.Sql_Set (set_op_to_extracted op, sql_query_to_extracted q1, sql_query_to_extracted q2)
  | ToCoq.Sql_Select (select, from, where, gby, having) ->
     Sql_query_to_js.Sql_Select (select_item_to_extracted select, List.map from_item_to_extracted from, sql_formula_to_extracted where, groub_by_to_extracted gby, sql_formula_to_extracted having)

and from_item_to_extracted : ToCoq.from_item -> Sql_query_to_js.relname Sql_query_to_js.sql_from_item = function
  | ToCoq.From_Item (q, ari) -> Sql_query_to_js.From_Item (sql_query_to_extracted q, att_renaming_item_to_extracted ari)

and sql_formula_to_extracted : ToCoq.sql_query Coq_sql_algebra.sql_formula -> Sql_query_to_js.relname Sql_query_to_js.sql_query0 Sql_query_to_js.sql_formula = function
  | Coq_sql_algebra.Sql_Conj (ao, f1, f2) -> Sql_query_to_js.Sql_Conj (and_or_to_extracted ao, sql_formula_to_extracted f1, sql_formula_to_extracted f2)
  | Coq_sql_algebra.Sql_Not f -> Sql_query_to_js.Sql_Not (sql_formula_to_extracted f)
  | Coq_sql_algebra.Sql_True -> Sql_query_to_js.Sql_True
  | Coq_sql_algebra.Sql_Pred (p, l) ->
     let (p, l) = predicate_to_extracted p (List.map aggterm_to_extracted l) in
     Sql_query_to_js.Sql_Pred (p, l)
  | Coq_sql_algebra.Sql_Quant (quant, p, l, q) ->
     (* Currently, only, =, < and <= are correctly extracted *)
     (* TODO: remove when predicates are not exported to binops but to
        any NRAEnv expression *)
     Sql_query_to_js.Sql_Quant (quantifier_to_extracted quant, Obj.magic (Util.char_list_of_string p), List.map aggterm_to_extracted l, sql_query_to_extracted q)
  | Coq_sql_algebra.Sql_In ((Coq_sql_algebra.Select_List l), q) -> Sql_query_to_js.Sql_In (List.map select_to_extracted l, sql_query_to_extracted q)
  | Coq_sql_algebra.Sql_In _ -> assert false
  | Coq_sql_algebra.Sql_Exists q -> Sql_query_to_js.Sql_Exists (sql_query_to_extracted q)


(** Glue for the database schema **)

let schema_to_extracted schema =
  fun r0 ->
  let r = Util.string r0 in
  try
    let attributes = List.assoc r schema in
    let la = List.map (fun (a, ty) ->
                 let a = Util.char_list_of_string ("."^a) in
                 let ra = r0@a in
                 match ty with
                   | Basics.TString -> Sql_query_to_js.Attr_string ra
                   | Basics.TInt -> Sql_query_to_js.Attr_Z ra
                   | Basics.TBool -> Sql_query_to_js.Attr_bool ra
               ) attributes
    in
    Sql_query_to_js.Fset.mk_set Sql_query_to_js.oAN Sql_query_to_js.fAN la
  with
    | Not_found -> Sql_query_to_js.Fset.empty Sql_query_to_js.oAN Sql_query_to_js.fAN


(** Pretty-printer for SQLAlg queries **)

let pp_list op sep cl elt out l =
  let rec _pp out l =
    match l with
      | [] -> ()
      | [e] -> Printf.fprintf out "%a" elt e
      | e::l -> Printf.fprintf out "%a%s%a" elt e sep _pp l in
  Printf.fprintf out "%s%a%s" op _pp l cl

let pp_list (elt:out_channel -> 'a -> unit) (out:out_channel) (l:'a list) : unit =
  pp_list "[" "; " "]" elt out l

let pp_option elt out = function
  | Some e -> Printf.fprintf out "(Some %a)" elt e
  | None -> Printf.fprintf out "None"

let pp_bool out b = Printf.fprintf out "%B" b
let pp_char_list out s = Printf.fprintf out "%s" (Util.string s)
let pp_int out i = Printf.fprintf out "%d" i

let pp_set_op out = function
  | Sql_query_to_js.Union -> Printf.fprintf out "Union"
  | Sql_query_to_js.UnionMax -> Printf.fprintf out "UnionMax"
  | Sql_query_to_js.Inter -> Printf.fprintf out "Inter"
  | Sql_query_to_js.Diff -> Printf.fprintf out "Diff"

let pp_tuple_attribute out (n:Sql_query_to_js.Tuple.attribute) =
  match Obj.magic n with
    | Sql_query_to_js.Attr_Z n -> Printf.fprintf out "(Attr_Z \"%s\"%%string)" (Util.string n)
    | Sql_query_to_js.Attr_string n -> Printf.fprintf out "(Attr_string \"%s\"%%string)" (Util.string n)
    | Sql_query_to_js.Attr_bool n -> Printf.fprintf out "(Attr_bool \"%s\"%%string)" (Util.string n)

let pp_tuple_aggregate out (a:Sql_query_to_js.Tuple.aggregate) =
  Printf.fprintf out "%s" (Util.string (Obj.magic a))

let pp_tuple_value out (v:Sql_query_to_js.Tuple.value) =
  match Obj.magic v with
    | Sql_query_to_js.NullValues.Value_bool v -> Printf.fprintf out "(Value_bool %a)" (pp_option pp_bool) v
    | Sql_query_to_js.NullValues.Value_string v -> Printf.fprintf out "(Value_string %a)" (pp_option pp_char_list) v
    | Sql_query_to_js.NullValues.Value_Z v -> Printf.fprintf out "(Value_Z %a)" (pp_option pp_int) v

let pp_tuple_symbol out (s:Sql_query_to_js.Tuple.symbol) =
  match Obj.magic s with
    | Sql_query_to_js.Symbol s -> Printf.fprintf out "(Symbol \"%s\"%%string)" (Util.string s)
    | Sql_query_to_js.CstVal v -> Printf.fprintf out "(CstVal %a)" pp_tuple_value v

let pp_tuple_predicate out (p:Sql_query_to_js.Tuple.predicate) =
  Printf.fprintf out "(Predicate \"%s\"%%string)" (Util.string (Obj.magic p))

let rec pp_funterm (out:out_channel) : Sql_query_to_js.funterm -> unit = function
  | Sql_query_to_js.F_Constant v -> Printf.fprintf out "(F_Constant %a)" pp_tuple_value v
  | Sql_query_to_js.F_Dot a -> Printf.fprintf out "(F_Dot %a)" pp_tuple_attribute a
  | Sql_query_to_js.F_Expr (s, l) -> Printf.fprintf out "(F_Expr %a %a)" pp_tuple_symbol s (pp_list pp_funterm) l

let rec pp_aggterm (out:out_channel) : Sql_query_to_js.aggterm -> unit = function
  | Sql_query_to_js.A_Expr f -> Printf.fprintf out "(A_Expr %a)" pp_funterm f
  | Sql_query_to_js.A_agg (a, f) -> Printf.fprintf out "(A_agg %a %a)" pp_tuple_aggregate a pp_funterm f
  | Sql_query_to_js.A_fun (s, l) -> Printf.fprintf out "(A_fun %a %a)" pp_tuple_symbol s (pp_list pp_aggterm) l

let pp_select out = function
  | Sql_query_to_js.Select_As (a, n) ->
     Printf.fprintf out "(Select_As %a %a)" pp_aggterm a pp_tuple_attribute n

let pp__select_list out (s:Sql_query_to_js._select_list) =
  pp_list pp_select out s

let pp_and_or out = function
  | Sql_query_to_js.And_F -> Printf.fprintf out "And_F"
  | Sql_query_to_js.Or_F -> Printf.fprintf out "Or_F"

let pp_quantifier out = function
  | Sql_query_to_js.Forall_F -> Printf.fprintf out "Forall_F"
  | Sql_query_to_js.Exists_F -> Printf.fprintf out "Exists_F"

let rec pp_query out (q:Sql_query_to_js.relname Sql_query_to_js.query0) =
  match q with
    | Sql_query_to_js.Q_Empty_Tuple -> Printf.fprintf out "Q_Empty_Tuple"
    | Sql_query_to_js.Q_Table r -> Printf.fprintf out "(Q_Table (Rel \"%s\"%%string))" (Util.string r)
    | Sql_query_to_js.Q_Set (op, q1, q2) -> Printf.fprintf out "(Q_Set %a %a %a)" pp_set_op op pp_query q1 pp_query q2
    | Sql_query_to_js.Q_NaturalJoin (q1, q2) -> Printf.fprintf out "(Q_NaturalJoin %a %a)" pp_query q1 pp_query q2
    | Sql_query_to_js.Q_Pi (pi, q) -> Printf.fprintf out "(Q_Pi (_Select_List %a) %a)" pp__select_list pi pp_query q
    | Sql_query_to_js.Q_Sigma (f, q) -> Printf.fprintf out "(Q_Sigma %a %a)" pp_sql_formula f pp_query q
    | Sql_query_to_js.Q_Gamma (pi, l, f, q) -> Printf.fprintf out "(Q_Gamma %a %a %a %a)" pp__select_list pi (pp_list pp_aggterm) l pp_sql_formula f pp_query q

and pp_sql_formula out = function
  | Sql_query_to_js.Sql_Conj (ao, f1, f2) -> Printf.fprintf out "(Sql_Conj %a %a %a)" pp_and_or ao pp_sql_formula f1 pp_sql_formula f2
  | Sql_query_to_js.Sql_Not f -> Printf.fprintf out "(Sql_Not %a)" pp_sql_formula f
  | Sql_query_to_js.Sql_True -> Printf.fprintf out "Sql_True"
  | Sql_query_to_js.Sql_Pred (p, l) -> Printf.fprintf out "(Sql_Pred %a %a)" pp_tuple_predicate p (pp_list pp_aggterm) l
  | Sql_query_to_js.Sql_Quant (qu, p, l, q) -> Printf.fprintf out "(Sql_Quant %a %a %a %a)" pp_quantifier qu pp_tuple_predicate p (pp_list pp_aggterm) l pp_query q
  | Sql_query_to_js.Sql_In (s, q) -> Printf.fprintf out "(Sql_In %a %a)" (pp_list pp_select) s pp_query q
  | Sql_query_to_js.Sql_Exists q -> Printf.fprintf out "(Sql_Exists %a)" pp_query q

